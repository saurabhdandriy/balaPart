package com.uas.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.NamedQuery;


@Entity
	@NamedQuery(name="getAllSchedule",query="select sb from ScheduleBean sb")
	



@Table(name="Programs_Scheduled")
public class ScheduleBean {
	
	@Id
	@GeneratedValue
	private int scheduleProgramId;
	private String programName;
	private String location;
	private String startDate;
	private String endDate;
	private int  SessionsPerWeek;
	public int getSessionsPerWeek() {
		return SessionsPerWeek;
	}
	public void setSessionsPerWeek(int sessionsPerWeek) {
		this.SessionsPerWeek = sessionsPerWeek;
	}
	public ScheduleBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ScheduleBean(int scheduleProgramId, String programName,
			String location, String startDate, String endDate,
			int sessionsPerWeek) {
		super();
		this.scheduleProgramId = scheduleProgramId;
		this.programName = programName;
		this.location = location;
		this.startDate = startDate;
		this.endDate = endDate;
		this.SessionsPerWeek = sessionsPerWeek;
	}
	public int getScheduleProgramId() {
		return scheduleProgramId;
	}
	public void setScheduleProgramId(int scheduleProgramId) {
		this.scheduleProgramId = scheduleProgramId;
	}
	public String getProgramName() {
		return programName;
	}
	public void setProgramName(String programName) {
		this.programName = programName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	
	@Override
	public String toString() {
		return "ScheduleProgramId  =  " + scheduleProgramId
				+ ", ProgramName  =  " + programName + ", Location  =  " + location
				+ ", StartDate  =  " + startDate + ", EndDate  =  " + endDate
				+ ", SessionsPerWeek  =  " + SessionsPerWeek;
	}
	
}
