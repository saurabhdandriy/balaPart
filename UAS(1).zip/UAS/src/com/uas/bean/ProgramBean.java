package com.uas.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.NamedQuery;

@Entity
@NamedQuery(name="getAllPrograms",query="select pb from ProgramBean pb")

@Table(name="Programs_Offered")
public class ProgramBean {
	
	@Id
	private String programName;
	private String description;
	private String eligibility;
	private int duration;
	private String certificateOffered;
	
	public String getProgramName() {
		return programName;
	}
	public void setProgramName(String programName) {
		this.programName = programName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getEligibility() {
		return eligibility;
	}
	@Override
	public String toString() {
		return "ProgramBean [programName=" + programName + ", description="
				+ description + ", eligibility=" + eligibility + ", duration="
				+ duration + ", certificateOffered=" + certificateOffered + "]";
	}
	public void setEligibility(String eligibility) {
		this.eligibility = eligibility;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	public String getCertificateOffered() {
		return certificateOffered;
	}
	public void setCertificateOffered(String certificateOffered) {
		this.certificateOffered = certificateOffered;
	}
	public ProgramBean(String programName, String description,
			String eligibility, int duration, String certificateOffered) {
		super();
		this.programName = programName;
		this.description = description;
		this.eligibility = eligibility;
		this.duration = duration;
		this.certificateOffered = certificateOffered;
	}
	public ProgramBean() {
		// TODO Auto-generated constructor stub
	}

}
